//---------------------------------------------------------------------------
#ifndef CommonH
#define CommonH
//---------------------------------------------------------------------------
#include <vcl.h>

#include <windows.h>
#include <setupapi.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
//---------------------------------------------------------------------------
#define BLANK		-2147483647
#define TEXTSIZE	256
//---------------------------------------------------------------------------
#endif
